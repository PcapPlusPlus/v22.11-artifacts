PcapPlusPlus Example Application
================================

This folder contains the source code and a Makefile of a simple application that uses PcapPlusPlus.

The code is based on the "Hello World" application in PcapPlusPlus Tutorials (https://pcapplusplus.github.io/docs/tutorials/intro#writing-a-simple-app-including-a-makefile).

In order to compile this application please follow the steps in README.release (the part that explains how to compile the application). 
You can skip the step which instructs to include `mk\PcapPlusPlus.mk` in the Makefile - this Makefile already includes this file.

